import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:open_filex/open_filex.dart';
import 'package:photo_view/photo_view.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/recent_display_item.dart';
import '../repositories/recent_repository.dart';
import '../database/database_helper.dart';

import '../models/note.dart';
import '../models/document.dart';
import '../models/media_item.dart';
import '../models/link_item.dart';
import '../models/whatsapp_chat.dart';

import 'note_details_screen.dart';
import 'whatsapp_chat_screen.dart';

import '../widgets/media_thumbnail.dart';
import '../widgets/pdf_thumbnail.dart';
import '../widgets/module_empty_state.dart';

class RecentScreen extends StatefulWidget {
  const RecentScreen({super.key});

  @override
  State<RecentScreen> createState() =>
      _RecentScreenState();
}

class _RecentScreenState
    extends State<RecentScreen> {
  final RecentRepository repository =
      RecentRepository();

  final DatabaseHelper database =
      DatabaseHelper.instance;

  List<RecentDisplayItem> items = [];

  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadRecentItems();
  }

  Future<void> loadRecentItems() async {
    final data =
        await repository.getDisplayItems();

    if (!mounted) return;

    setState(() {
      items = data;
      loading = false;
    });
  }
    String formatTime(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inSeconds < 30) {
      return "Just now";
    }

    if (difference.inMinutes < 60) {
      return "${difference.inMinutes} min ago";
    }

    if (difference.inHours < 24) {
      return "${difference.inHours} hr ago";
    }

    if (difference.inDays == 1) {
      return "Yesterday";
    }

    if (difference.inDays < 7) {
      return "${difference.inDays} days ago";
    }

    return DateFormat("dd MMM yyyy").format(date);
  }

  IconData getIcon(String type) {
    switch (type) {
      case "note":
        return Icons.note;

      case "document":
        return Icons.picture_as_pdf;

      case "media":
        return Icons.perm_media;

      case "link":
        return Icons.link;

      case "whatsapp":
        return Icons.chat;

      default:
        return Icons.insert_drive_file;
    }
  }

  Color getIconColor(String type) {
    switch (type) {
      case "note":
        return Colors.orange;

      case "document":
        return Colors.red;

      case "media":
        return Colors.green;

      case "link":
        return Colors.blue;

      case "whatsapp":
        return Colors.teal;

      default:
        return Colors.grey;
    }
  }

  Widget buildThumbnail(
    RecentDisplayItem item,
  ) {
    if (item.type == "media" &&
        item.thumbnail != null &&
        File(item.thumbnail!).existsSync()) {
      return ClipRRect(
        borderRadius:
            BorderRadius.circular(10),
        child: Image.file(
          File(item.thumbnail!),
          width: 56,
          height: 56,
          fit: BoxFit.cover,
        ),
      );
    }

    return Container(
      width: 56,
      height: 56,
      decoration: BoxDecoration(
        color: getIconColor(item.type)
            .withOpacity(0.12),
        borderRadius:
            BorderRadius.circular(12),
      ),
      child: Icon(
        getIcon(item.type),
        color: getIconColor(item.type),
        size: 30,
      ),
    );
  }